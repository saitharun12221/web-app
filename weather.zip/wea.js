const APIKEY="d8000de425e0520ed4afaf8d828a441c";
const apiurl="https://api.openweathermap.org/data/2.5/weather?units=metric&q=";
const searchBox = document.querySelector(".search input");
const searchBtn = document.querySelector(".search button");
const weaIcon= document.querySelector(".weaicon");
async function checkweather(city){
	const response = await fetch(apiurl + city + `&appid=${APIKEY}` );
	if(response.status == 404){
		document.querySelector(".error").style.display ="block";
		document.querySelector(".weas").style.display ="none";
	}
	else{
		var data=await response.json();
		console.log(data);
		document.querySelector(".city").innerHTML=data.name;
		document.querySelector(".temp").innerHTML=Math.round(data.main.temp) + "°C";
		document.querySelector(".humidity").innerHTML=data.main.humidity + "%";
		document.querySelector(".wind").innerHTML=data.wind.speed + "kmph";

		if(data.weather[0]. main=="Clouds"){
		weaIcon.src="clouds.png";
			}
		else if(data.weather[0]. main=="Clear"){
		weaIcon.src="clear.png";
			}
		else if(data.weather[0]. main=="Drizzle"){
		weaIcon.src="drizzle.png";
			}	
		else if(data.weather[0]. main=="Snow"){
		weaIcon.src="snow.png";
			}
		else if(data.weather[0]. main=="Mist"){
		weaIcon.src="mist.png";
			}
		else if(data.weather[0]. main=="Rain"){
		weaIcon.src="rain.png";
			}
		document.querySelector(".weas").style.display ="block";
		document.querySelector(".error").style.display ="none";
	}
	
}
	
searchBtn.addEventListener("click", ()=>{
	checkweather(searchBox.value)
})



